package main.java.uia.com.contabilidad.clientes;

public class ListaNotaDebito extends ListaInfoUIA{
	public ListaNotaDebito() {
		super();
		// TODO Auto-generated constructor stub
	}
}
