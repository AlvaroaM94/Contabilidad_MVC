package main.java.uia.com.contabilidad.clientes;

import java.util.ArrayList;



public class ListaClientes extends ListaInfoUIA
{

	public ListaClientes() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}


